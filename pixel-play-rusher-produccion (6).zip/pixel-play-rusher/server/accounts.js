'use strict';
/* Pixel Play Rusher · cuentas online.
   - Registro con nombre de usuario ÚNICO (sin distinguir mayúsculas ni tildes) y contraseña guardada como hash scrypt.
   - El servidor es quien manda en el progreso y en la moneda PX: reparte tras cada partida, cobra colores y recompensas de rango,
     y acredita las compras de la tienda (Stripe Checkout + webhook firmado). El panel de administración puede sumar o restar PX.
   Rutas: /api/auth/*, /api/me*, /api/store*  y, en el panel, /api/admin/accounts, /px y /orders. */

const crypto = require('crypto');
const path = require('path');
const { Store } = require('./admin.js');

const scrypt = (pw, salt) => new Promise((res, rej) => crypto.scrypt(pw, salt, 64, { N: 16384, r: 8, p: 1 }, (e, k) => (e ? rej(e) : res(k))));
const hex = n => crypto.randomBytes(n).toString('hex');
const sha = x => crypto.createHash('sha256').update(String(x)).digest('hex');
const clean = (s, n) => String(s == null ? '' : s).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, n);
const ukey = n => String(n || '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]/g, '');
const normEmail = e => String(e || '').trim().toLowerCase();
const validEmail = e => /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/.test(e) && e.length <= 254;
const maskEmail = e => (e ? e.replace(/^(.{2})[^@]*(@.*)$/, '$1***$2') : '');
const SESSION_MS = 30 * 86400000;
const EMPTY_STATS = () => ({ games: 0, kills: 0, deaths: 0, wins: 0, streak: 0, points: 0, best: 0 });

function createAccounts({ dataDir, log, S, admin, env = process.env }) {
  const now = () => Date.now();
  const db = new Store(path.join(dataDir, 'accounts.json'), { seq: 0, users: {}, sessions: {}, orders: [], pxlog: [] }, log);
  const D = db.data;
  const byId = new Map(Object.values(D.users).map(u => [u.id, u]));
  const REG_MAX = +env.ACCOUNTS_REG_MAX || 5;                 // registros por IP y hora
  const PX_DAILY_CAP = +env.PX_DAILY_CAP || 5000;             // PX máximos por cuenta y día que se pueden ganar jugando
  const ALLOWED_ORIGINS = String(env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);

  /* ---------- Tienda (Stripe Checkout) ---------- */
  const STRIPE_KEY = String(env.STRIPE_SECRET_KEY || ''), STRIPE_WH = String(env.STRIPE_WEBHOOK_SECRET || '');
  const STRIPE_BASE = String(env.STRIPE_API_BASE || 'https://api.stripe.com').replace(/\/+$/, '');
  const PUBLIC_URL = String(env.PUBLIC_URL || '').replace(/\/+$/, '');
  const CURRENCY = String(env.STORE_CURRENCY || 'eur').toLowerCase().slice(0, 3);
  let PACKS = [{ id: 'px500', px: 500, price: 99 }, { id: 'px1300', px: 1300, price: 199, tag: '+30 %' }, { id: 'px3500', px: 3500, price: 499, tag: '+40 %' }, { id: 'px8000', px: 8000, price: 999, tag: '+60 %' }];
  try { if (env.STORE_PACKS) { const p = JSON.parse(env.STORE_PACKS); if (Array.isArray(p) && p.length) PACKS = p.filter(x => x && /^[a-z0-9_-]{2,20}$/.test(x.id) && x.px > 0 && x.price >= 50).slice(0, 8); } } catch (e) { log('STORE_PACKS no es un JSON válido: se usan los paquetes por defecto.'); }
  const storeOn = () => !!(STRIPE_KEY && PUBLIC_URL);
  const storeInfo = () => ({ enabled: storeOn(), currency: CURRENCY, packs: PACKS.map(p => ({ id: p.id, px: p.px, price: p.price, tag: p.tag || '' })), reason: storeOn() ? '' : 'El dueño de la web aún no ha activado los pagos.' });

  /* ---------- Cuentas y sesiones ---------- */
  const fails = new Map(), regHits = new Map();
  const pub = u => ({ id: u.id, username: u.username, px: u.px, stats: u.stats, unlocked: u.unlocked, claimed: u.claimed, createdAt: u.createdAt });
  function newSession(u) {
    const token = hex(32), t = now();
    D.sessions[sha(token)] = { uid: u.id, exp: t + SESSION_MS };
    const mine = Object.entries(D.sessions).filter(([, s]) => s.uid === u.id).sort((a, b) => a[1].exp - b[1].exp);
    for (const [k] of mine.slice(0, Math.max(0, mine.length - 5))) delete D.sessions[k];      // como mucho 5 sesiones abiertas por cuenta
    if (Object.keys(D.sessions).length > 20000) for (const [k, s] of Object.entries(D.sessions)) if (s.exp < t) delete D.sessions[k];
    db.save(); return token;
  }
  function fromToken(token) {
    if (!token || typeof token !== 'string' || token.length > 100) return null;
    const s = D.sessions[sha(token)]; if (!s) return null;
    if (s.exp < now()) { delete D.sessions[sha(token)]; return null; }
    return byId.get(s.uid) || null;
  }
  const nameTaken = name => !!D.users[ukey(name)];
  const err = (code, error) => ({ code, error });

  function checkUsername(name) {
    name = String(name || '').trim();
    if (name.length < 3) return 'Mínimo 3 caracteres.'; if (name.length > 14) return 'Máximo 14 caracteres.';
    if (!/^[\p{L}\p{N}_-]+$/u.test(name)) return 'Solo letras, números, _ y -.';
    if (ukey(name).length < 3) return 'Usa letras del alfabeto latino o números.';
    if (/^guest/i.test(name) || /^invitado/i.test(name)) return 'Ese nombre está reservado para invitados.';
    return '';
  }
  async function register(b, ip) {
    const t = now(), hits = (regHits.get(ip) || []).filter(x => t - x < 3600000);
    if (hits.length >= REG_MAX) return err(429, 'Demasiados registros desde tu conexión. Inténtalo más tarde.');
    const username = String(b.username || '').trim(), email = normEmail(b.email), pw = String(b.password || '');
    const e = checkUsername(username); if (e) return err(400, e);
    if (!validEmail(email)) return err(400, 'El correo no parece válido.');
    if (pw.length < 8 || pw.length > 128 || !/\p{L}/u.test(pw) || !/\p{N}/u.test(pw)) return err(400, 'La contraseña necesita 8 caracteres o más, con letras y números.');
    const ban = admin.banFor(username, ip); if (ban) return err(403, admin.banMessage(ban));
    if (admin.isReserved(username)) return err(400, 'Ese nombre está reservado.');
    const key = ukey(username);
    if (D.users[key]) return err(409, 'Ese nombre de usuario ya está en uso. Elige otro.');
    if (Object.values(D.users).some(u => u.email === email)) return err(409, 'Ese correo ya tiene una cuenta.');
    hits.push(t); regHits.set(ip, hits);
    const salt = hex(16), hash = (await scrypt(pw, salt)).toString('hex');
    if (D.users[key]) return err(409, 'Ese nombre de usuario ya está en uso. Elige otro.');   // otra petición pudo ganarle mientras se calculaba el hash
    const u = { id: ++D.seq, username, key, email, salt, hash, createdAt: t, lastLogin: t, px: 0, stats: EMPTY_STATS(), unlocked: [0, 1, 2, 3], claimed: [], day: { d: '', px: 0 } };
    D.users[key] = u; byId.set(u.id, u); db.save();
    log('Cuenta nueva: ' + username);
    return { ok: true, token: newSession(u), profile: pub(u) };
  }
  async function login(b, ip) {
    const idf = String(b.identifier || '').trim(), pw = String(b.password || '');
    const kIp = 'ip:' + ip, kId = 'id:' + (ukey(idf) || normEmail(idf));
    const t = now(); for (const k of [kIp, kId]) { const f = fails.get(k); if (f && f.until > t) return err(429, 'Demasiados intentos. Espera ' + Math.ceil((f.until - t) / 1000) + ' s.'); }
    const u = D.users[ukey(idf)] || Object.values(D.users).find(x => idf.includes('@') && x.email === normEmail(idf)) || null;
    let good = false;
    try { const h = await scrypt(pw, u ? u.salt : 'a'.repeat(32)), st = Buffer.from(u ? u.hash : 'b'.repeat(128), 'hex'); good = !!u && h.length === st.length && crypto.timingSafeEqual(h, st); } catch (e) { good = false; }
    if (!good) {
      for (const [k, lim] of [[kIp, 6], [kId, 8]]) { const f = fails.get(k) || { n: 0, until: 0 }; f.n++; if (f.n >= lim) { f.n = 0; f.until = t + 5 * 60000; } fails.set(k, f); }
      return err(401, 'Usuario o contraseña incorrectos.');
    }
    fails.delete(kIp); fails.delete(kId);
    const ban = admin.banFor(u.username, ip); if (ban) return err(403, admin.banMessage(ban));
    u.lastLogin = t; return { ok: true, token: newSession(u), profile: pub(u) };
  }

  /* ---------- Progreso y monedero ---------- */
  const today = () => new Date().toISOString().slice(0, 10);
  function awardMatch(u, r) {
    const st = u.stats, prevBest = st.best; let px = S.pxFor(r.points, r.won, r.cls);
    st.games++; st.kills += r.kills; st.deaths += r.deaths; st.wins += r.won ? 1 : 0; st.streak = Math.max(st.streak, r.bestStreak || 0); st.points += r.points; st.best = Math.max(st.best, r.points);
    if (u.day.d !== today()) u.day = { d: today(), px: 0 };
    px = Math.max(0, Math.min(px, PX_DAILY_CAP - u.day.px)); u.day.px += px; u.px += px;    // tope diario contra el granjeo entre cuentas
    db.save(); return { px, balance: u.px, prevBest, stats: st, mult: S.eventMult(S.todayEvent(), r.cls) };
  }
  function unlockColor(u, i) {
    i = i | 0; const cost = S.COLOR_COSTS[i];
    if (cost == null) return err(400, 'Color no válido.'); if (u.unlocked.includes(i)) return err(400, 'Ya lo tienes.');
    if (u.px < cost) return err(402, 'Te faltan ' + (cost - u.px) + ' PX.');
    u.px -= cost; u.unlocked.push(i); db.save(); return { ok: true, profile: pub(u) };
  }
  function claimRank(u, i) {
    i = i | 0; const r = S.RANKS[i];
    if (!r) return err(400, 'Rango no válido.'); if (u.stats.points < r.pts) return err(400, 'Aún no has alcanzado ese rango.'); if (u.claimed.includes(i)) return err(400, 'Ya reclamaste esa recompensa.');
    u.claimed.push(i); u.px += r.kr; if (r.color != null && !u.unlocked.includes(r.color)) u.unlocked.push(r.color);
    db.save(); return { ok: true, profile: pub(u), gained: r.kr };
  }
  function adjust(username, delta, reason, by) {
    const u = D.users[ukey(username)]; if (!u) return err(404, 'No existe ninguna cuenta con ese nombre.');
    delta = Math.trunc(+delta); if (!Number.isFinite(delta) || delta === 0 || Math.abs(delta) > 1000000) return err(400, 'La cantidad debe ser un número entero distinto de 0 (máximo 1.000.000).');
    const applied = delta < 0 ? -Math.min(u.px, -delta) : delta; u.px += applied;
    D.pxlog.unshift({ ts: now(), user: u.username, delta, applied, balance: u.px, reason: clean(reason, 120), by });
    if (D.pxlog.length > 2000) D.pxlog.length = 2000; db.save();
    return { ok: true, username: u.username, applied, balance: u.px };
  }

  /* Cobro y abono de PX para otros módulos (pase de batalla). spend() no deja saldos negativos: devuelve false si no alcanza. */
  function spend(u, n, reason) {
    n = Math.trunc(n); if (!(n > 0) || u.px < n) return false;
    u.px -= n; D.pxlog.unshift({ ts: now(), user: u.username, delta: -n, applied: -n, balance: u.px, reason: clean(reason, 120), by: 'juego' }); if (D.pxlog.length > 2000) D.pxlog.length = 2000; db.save(); return true;
  }
  function grant(u, n, reason) {
    n = Math.trunc(n); if (!(n > 0)) return; u.px += n;
    D.pxlog.unshift({ ts: now(), user: u.username, delta: n, applied: n, balance: u.px, reason: clean(reason, 120), by: 'juego' }); if (D.pxlog.length > 2000) D.pxlog.length = 2000; db.save();
  }
  const find = name => D.users[ukey(name)] || null;

  /* ---------- Compras (Stripe Checkout) ---------- */
  async function checkout(u, packId) {
    if (!storeOn()) return err(503, storeInfo().reason);
    const pack = PACKS.find(p => p.id === packId); if (!pack) return err(400, 'Paquete no válido.');
    const f = new URLSearchParams();
    f.set('mode', 'payment'); f.set('success_url', PUBLIC_URL + '/?px=ok'); f.set('cancel_url', PUBLIC_URL + '/?px=cancel');
    f.set('client_reference_id', String(u.id)); f.set('metadata[pack]', pack.id); f.set('metadata[uid]', String(u.id));
    f.set('line_items[0][quantity]', '1'); f.set('line_items[0][price_data][currency]', CURRENCY); f.set('line_items[0][price_data][unit_amount]', String(pack.price));
    f.set('line_items[0][price_data][product_data][name]', pack.px + ' PX · Pixel Play Rusher');
    let j; try {
      const r = await fetch(STRIPE_BASE + '/v1/checkout/sessions', { method: 'POST', headers: { Authorization: 'Bearer ' + STRIPE_KEY, 'Content-Type': 'application/x-www-form-urlencoded' }, body: f, signal: AbortSignal.timeout(15000) });
      j = await r.json(); if (!r.ok || !j.url || !j.id) { log('Stripe rechazó la sesión de pago: ' + clean(j && j.error && j.error.message, 120)); return err(502, 'No se pudo iniciar el pago. Inténtalo más tarde.'); }
    } catch (e) { log('No se pudo contactar con Stripe: ' + e.message); return err(502, 'No se pudo iniciar el pago. Inténtalo más tarde.'); }
    D.orders.unshift({ id: j.id, uid: u.id, user: u.username, pack: pack.id, px: pack.px, amount: pack.price, currency: CURRENCY, status: 'pending', ts: now() });
    if (D.orders.length > 2000) D.orders.length = 2000; db.save();
    return { ok: true, url: j.url };
  }
  function verifySignature(raw, header) {
    if (!STRIPE_WH || !header) return false;
    const parts = Object.fromEntries(String(header).split(',').map(x => x.trim().split('=')).filter(x => x.length === 2));
    const ts = +parts.t; if (!ts || Math.abs(now() / 1000 - ts) > 300) return false;
    const expected = crypto.createHmac('sha256', STRIPE_WH).update(ts + '.' + raw).digest('hex');
    return String(header).split(',').map(x => x.trim()).filter(x => x.startsWith('v1=')).some(x => { const v = x.slice(3); return v.length === expected.length && crypto.timingSafeEqual(Buffer.from(v), Buffer.from(expected)); });
  }
  function webhook(raw, header) {
    if (!verifySignature(raw, header)) return err(400, 'Firma no válida.');
    let ev; try { ev = JSON.parse(raw); } catch (e) { return err(400, 'JSON no válido.'); }
    const o = ev && ev.data && ev.data.object;
    if (ev && (ev.type === 'checkout.session.completed' || ev.type === 'checkout.session.async_payment_succeeded') && o && o.payment_status === 'paid') {
      const order = D.orders.find(x => x.id === o.id);
      if (!order) { log('Pago recibido de una sesión desconocida: ' + clean(o.id, 40)); return { ok: true }; }
      if (order.status === 'paid') return { ok: true };                       // ya acreditado (Stripe reintenta los avisos)
      if (o.amount_total !== order.amount || String(o.currency).toLowerCase() !== order.currency) { order.status = 'mismatch'; db.save(); log('Pago con importe distinto al pedido ' + order.id); return { ok: true }; }
      const u = byId.get(order.uid); if (!u) { order.status = 'orphan'; db.save(); return { ok: true }; }
      u.px += order.px; order.status = 'paid'; order.paidAt = now(); db.save(); log('PX comprados: ' + order.px + ' para ' + u.username);
    }
    return { ok: true };
  }

  /* ---------- HTTP ---------- */
  const handles = p => p.startsWith('/api/auth/') || p === '/api/me' || p.startsWith('/api/me/') || p.startsWith('/api/store');
  const hits = new Map(); const hitTimer = setInterval(() => hits.clear(), 60000); if (hitTimer.unref) hitTimer.unref();
  const readRaw = (req, max) => new Promise((res, rej) => { let n = 0; const parts = []; req.on('data', c => { n += c.length; if (n > max) { rej(new Error('cuerpo demasiado grande')); req.destroy(); } else parts.push(c); }); req.on('end', () => res(Buffer.concat(parts).toString('utf8'))); req.on('error', rej); });
  function send(req, res, code, obj) {
    const h = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' };
    const origin = req.headers.origin; if (origin && ALLOWED_ORIGINS.includes(origin)) { h['Access-Control-Allow-Origin'] = origin; h.Vary = 'Origin'; h['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'; h['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'; }
    res.writeHead(code, h); res.end(obj == null ? '' : JSON.stringify(obj));
  }
  async function handleHttp(req, res, url, ip) {
    if (!handles(url.pathname)) return false;
    if (req.method === 'OPTIONS') { send(req, res, 204, null); return true; }
    const n = (hits.get(ip) || 0) + 1; hits.set(ip, n); if (n > 300) { send(req, res, 429, { error: 'Demasiadas peticiones.' }); return true; }
    const key = req.method + ' ' + url.pathname;
    try {
      if (key === 'POST /api/store/webhook') { const r = webhook(await readRaw(req, 100000), req.headers['stripe-signature']); send(req, res, r.code || 200, r.error ? { error: r.error } : { ok: true }); return true; }
      const body = req.method === 'POST' ? (() => readRaw(req, 4000).then(t => (t ? JSON.parse(t) : {})))() : Promise.resolve({});
      const b = await body;
      let out;
      if (key === 'POST /api/auth/register') out = await register(b, ip);
      else if (key === 'POST /api/auth/login') out = await login(b, ip);
      else if (key === 'GET /api/store') out = storeInfo();
      else {
        const h = String(req.headers.authorization || ''), token = h.startsWith('Bearer ') ? h.slice(7) : '', u = fromToken(token);
        if (!u) { send(req, res, 401, { error: 'Sesión no válida o caducada.' }); return true; }
        if (key === 'GET /api/me') out = { ok: true, profile: pub(u) };
        else if (key === 'POST /api/auth/logout') { delete D.sessions[sha(token)]; db.save(); out = { ok: true }; }
        else if (key === 'POST /api/me/unlock') out = unlockColor(u, b.i);
        else if (key === 'POST /api/me/claim') out = claimRank(u, b.i);
        else if (key === 'POST /api/store/checkout') out = await checkout(u, String(b.pack || ''));
        else { send(req, res, 404, { error: 'No encontrado.' }); return true; }
      }
      send(req, res, out.code || 200, out.error ? { error: out.error } : out);
    } catch (e) { send(req, res, 400, { error: e.message === 'cuerpo demasiado grande' ? e.message : 'Petición no válida.' }); }
    return true;
  }

  /* ---------- Rutas del panel de administración ---------- */
  admin.addRoutes({
    'GET /accounts': ({ q }) => {
      const s = ukey(q.get('q')), list = Object.values(D.users).filter(u => !s || u.key.includes(s) || u.email.includes(String(q.get('q')).toLowerCase())).sort((a, b) => b.createdAt - a.createdAt);
      return { total: Object.keys(D.users).length, accounts: list.slice(0, 100).map(u => ({ username: u.username, email: maskEmail(u.email), px: u.px, points: u.stats.points, games: u.stats.games, createdAt: u.createdAt, lastLogin: u.lastLogin })) };
    },
    'POST /px': ({ b, s }) => { const r = adjust(b.username, b.delta, b.reason, s.user); if (!r.error) admin.audit(s.user, 'px-' + (r.applied >= 0 ? 'sumar' : 'restar'), r.username + ' ' + (r.applied >= 0 ? '+' : '') + r.applied + ' PX' + (b.reason ? ' · ' + clean(b.reason, 80) : '')); return r; },
    'GET /orders': () => ({ enabled: storeOn(), orders: D.orders.slice(0, 200), pxlog: D.pxlog.slice(0, 100) })
  });

  const readJson = req => readRaw(req, 4000).then(t => (t ? JSON.parse(t) : {}));
  return { handleHttp, handles, fromToken, nameTaken, awardMatch, profile: pub, flush: () => db.flush(), adjust, register, storeInfo, spend, grant, find, http: { send, readJson } };
}

module.exports = { createAccounts, ukey };
